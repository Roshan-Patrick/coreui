import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NurseRegService } from '../service/nurse-reg.service';

@Component({
  selector: 'app-page404',
  templateUrl: './page404.component.html',
  styleUrls: ['./page404.component.scss']
})
export class Page404Component {

  bookingForm: any;

  constructor(private fb: FormBuilder,private nurseService:NurseRegService, private router: Router) {}

  ngOnInit(): void {
    this.bookingForm = this.fb.group({
      name: ['', Validators.required],
      mobile: ['', [Validators.required, Validators.pattern(/^\d{10}$/)]],
      nurseType: ['', Validators.required],
      location: ['', Validators.required],
      services: ['', Validators.required],
      preferences: ['', Validators.required],
      agreement: [false, Validators.requiredTrue]
    });
  }

  onSubmit(): void {
    if (this.bookingForm.valid) {
      // Create a copy of the form value, excluding the `agreement` field
      const formData = { ...this.bookingForm.value };
      delete formData.agreement;
  
      console.log(formData);
      this.nurseService
        .nurseRegistration(formData) // Use the modified data
        .subscribe({
          next: (res) => {
            console.log('Success:', res);
            const modal = document.getElementById('successModal');
            if (modal) modal.classList.add('active');
          },
          error: (err) => console.error('Error:', err),
        });
    }
  }

  redirectToNurse() {
    this.router.navigate(['/page/nurse']); 
  
    }

}
